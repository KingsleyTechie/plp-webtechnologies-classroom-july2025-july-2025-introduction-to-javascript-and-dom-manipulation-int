/*
 * Week 5 Assignment - JavaScript Fundamentals
 * This script demonstrates my understanding of core JavaScript concepts
 * I've organized the code by assignment parts for clarity
 */

// ===========================================
// PART 1: VARIABLE DECLARATIONS AND CONDITIONALS
// ===========================================

// I'm declaring different types of variables to show my understanding
const userName = "Alex"; // Using const for values that won't change
let userScore = 0; // Using let for values that might change
var isOnline = true; // Using var for broader scope (though I know let is preferred now)
const MAX_SCORE = 100; // Constant value in uppercase as convention

// This function demonstrates conditional statements
function checkWeather() {
    // I'm getting a random temperature to make this more interesting
    const temperature = Math.floor(Math.random() * 40); // 0-39 degrees
    const isRaining = Math.random() > 0.5; // 50% chance of rain
    
    let weatherMessage = `Current conditions: ${temperature}°C and ${isRaining ? 'raining' : 'dry'}. `;
    
    // Using conditionals to provide different recommendations
    if (temperature > 30) {
        weatherMessage += "It's hot! Stay hydrated and wear light clothing.";
    } else if (temperature > 20) {
        weatherMessage += "Perfect weather! Great day for outdoor activities.";
    } else if (temperature > 10) {
        weatherMessage += "A bit chilly. A light jacket would be good.";
    } else if (temperature > 0) {
        weatherMessage += "It's cold. Wear a warm coat.";
    } else {
        weatherMessage += "Freezing! Bundle up with heavy winter gear.";
    }
    
    // Additional condition based on rain
    if (isRaining) {
        weatherMessage += " Don't forget your umbrella!";
    }
    
    return weatherMessage;
}

// ===========================================
// PART 2: CUSTOM FUNCTIONS
// ===========================================

// Function 1: Calculate the sum of two numbers
// I'm making this function flexible to handle different data types
function calculateSum(num1, num2) {
    // Converting to numbers to handle string inputs
    const number1 = Number(num1);
    const number2 = Number(num2);
    
    // Validating the inputs
    if (isNaN(number1) || isNaN(number2)) {
        return "Please enter valid numbers!";
    }
    
    return number1 + number2;
}

// Function 2: Find the larger of two numbers
// This demonstrates returning different values based on conditions
function findLargerNumber(a, b) {
    const numA = Number(a);
    const numB = Number(b);
    
    if (isNaN(numA) || isNaN(numB)) {
        return "Invalid input - please enter numbers";
    }
    
    if (numA > numB) {
        return `${numA} is larger than ${numB}`;
    } else if (numB > numA) {
        return `${numB} is larger than ${numA}`;
    } else {
        return "Both numbers are equal";
    }
}

// ===========================================
// PART 3: LOOP EXAMPLES
// ===========================================

// Loop Example 1: For loop to count up to a number
function countWithForLoop(limit) {
    let result = "Counting: ";
    
    // Using a for loop to iterate a specific number of times
    for (let i = 1; i <= limit; i++) {
        result += i;
        if (i < limit) {
            result += ", ";
        }
    }
    
    return result;
}

// Loop Example 2: While loop to create a multiplication table
function createMultiplicationTable(number) {
    if (number < 1 || number > 10) {
        return "Please enter a number between 1 and 10";
    }
    
    let result = `Multiplication table for ${number}:<br>`;
    let counter = 1;
    
    // Using a while loop when we don't know the exact number of iterations in advance
    while (counter <= 10) {
        result += `${number} × ${counter} = ${number * counter}<br>`;
        counter++; // Don't forget to increment to avoid infinite loops!
    }
    
    return result;
}

// ===========================================
// PART 4: DOM INTERACTIONS
// ===========================================

// DOM Interaction 1: Adding items to a list
function addListItem() {
    const newItemText = document.getElementById('newItem').value.trim();
    
    if (newItemText === "") {
        alert("Please enter some text for the list item!");
        return;
    }
    
    const list = document.getElementById('dynamicList');
    const newItem = document.createElement('li');
    
    // Adding text and a delete button to the list item
    newItem.innerHTML = `
        <span>${newItemText}</span>
        <button class="delete-btn">Delete</button>
    `;
    
    // Adding animation class
    newItem.classList.add('fade-in');
    
    // Adding event listener to the delete button
    newItem.querySelector('.delete-btn').addEventListener('click', function() {
        list.removeChild(newItem);
    });
    
    list.appendChild(newItem);
    
    // Clear the input field
    document.getElementById('newItem').value = "";
}

// DOM Interaction 2: Changing background color
function changeBackgroundColor() {
    const colors = ['#f8f9fa', '#e8f4f8', '#f0e8f8', '#f8f0e8', '#e8f8f0'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    document.body.style.backgroundColor = randomColor;
}

// DOM Interaction 3: Toggling list visibility
function toggleListVisibility() {
    const list = document.getElementById('dynamicList');
    
    if (list.style.display === 'none') {
        list.style.display = 'block';
    } else {
        list.style.display = 'none';
    }
}

// DOM Interaction 4: Clearing all list items
function clearAllItems() {
    const list = document.getElementById('dynamicList');
    
    if (list.children.length === 0) {
        alert("The list is already empty!");
        return;
    }
    
    if (confirm("Are you sure you want to clear all items?")) {
        list.innerHTML = '';
    }
}

// ===========================================
// SETTING UP EVENT LISTENERS
// ===========================================

// I'm using DOMContentLoaded to ensure the HTML is fully loaded before running scripts
document.addEventListener('DOMContentLoaded', function() {
    console.log("Week 5 Assignment loaded successfully!");
    
    // Part 1: Weather button
    document.getElementById('checkWeather').addEventListener('click', function() {
        const weatherMessage = checkWeather();
        document.getElementById('weatherOutput').textContent = weatherMessage;
    });
    
    // Part 2: Function buttons
    document.getElementById('calculateSum').addEventListener('click', function() {
        const num1 = document.getElementById('num1').value;
        const num2 = document.getElementById('num2').value;
        const sum = calculateSum(num1, num2);
        document.getElementById('functionOutput').textContent = `The sum is: ${sum}`;
    });
    
    document.getElementById('findLarger').addEventListener('click', function() {
        const num1 = document.getElementById('num1').value;
        const num2 = document.getElementById('num2').value;
        const result = findLargerNumber(num1, num2);
        document.getElementById('functionOutput').textContent = result;
    });
    
    // Part 3: Loop buttons
    document.getElementById('countWithFor').addEventListener('click', function() {
        const number = document.getElementById('loopNumber').value;
        const result = countWithForLoop(Number(number));
        document.getElementById('loopOutput').textContent = result;
    });
    
    document.getElementById('multiplyWithWhile').addEventListener('click', function() {
        const number = document.getElementById('loopNumber').value;
        const result = createMultiplicationTable(Number(number));
        document.getElementById('loopOutput').innerHTML = result;
    });
    
    // Part 4: DOM interaction buttons
    document.getElementById('addItem').addEventListener('click', addListItem);
    
    // Allow adding items with Enter key
    document.getElementById('newItem').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            addListItem();
        }
    });
    
    document.getElementById('changeColor').addEventListener('click', changeBackgroundColor);
    document.getElementById('toggleVisibility').addEventListener('click', toggleListVisibility);
    document.getElementById('clearAll').addEventListener('click', clearAllItems);
});

// ===========================================
// ADDITIONAL DEMONSTRATION (not required but helpful)
// ===========================================

// Showing array methods which often use loops internally
function demonstrateArrayMethods() {
    const fruits = ['apple', 'banana', 'orange', 'grape'];
    console.log("Original array:", fruits);
    
    // Using forEach (a type of loop)
    console.log("Using forEach:");
    fruits.forEach(fruit => console.log(fruit));
    
    // Using map (creates a new array)
    const fruitLengths = fruits.map(fruit => fruit.length);
    console.log("Fruit name lengths:", fruitLengths);
}